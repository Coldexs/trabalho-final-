package br.edu.univille.poo2.login.controller.web;

import br.edu.univille.poo2.login.core.entity.User;

import br.edu.univille.poo2.login.core.entity.UserRole;
import br.edu.univille.poo2.login.core.repository.UserRepository;
import br.edu.univille.poo2.login.core.repository.UserRoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/register")
public class RegistrationController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserRoleRepository roleRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;  // Para codificar a senha

    // Exibe a página de registro
    @GetMapping
    public ModelAndView registrationPage() {
        return new ModelAndView("register");
    }

    // Registra o usuário
    @PostMapping
    public String registerUser(@Validated @ModelAttribute User user, Model model) {
        // Validação: Verificar se o nome de usuário já existe
        if (userRepository.existsByUsername(user.getUsername())) {
            model.addAttribute("error", "Nome de usuário já está em uso!");
            return "register";
        }

        // Criação do novo usuário
        user.setPassword(passwordEncoder.encode(user.getPassword()));  // Hash da senha

        // Obtém a Role "USER" do repositório
        Role userRole = roleRepository.findById(1L)
                .orElseThrow(() -> new IllegalStateException("Role 'USER' não encontrada."));
        user.setRole(userRole);
        user.setActive(true);

        // Salvar usuário no repositório
        userRepository.save(user);

        // Redirecionar para a página de login
        return "redirect:/login";
    }
}

package br.edu.univille.poo2.login.core.service;

import br.edu.univille.poo2.login.core.entity.Receita;
import br.edu.univille.poo2.login.core.repository.ReceitaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReceitaService {

    @Autowired
    private ReceitaRepository repository;

    // Listar todas as receitas
    public List<Receita> listarTodas() {
        return repository.findAll();  // Retorna todas as receitas
    }

    // Adicionar uma nova receita
    public Receita salvar(Receita receita) {
        return repository.save(receita);  // Salva uma receita no banco
    }

    // Editar uma receita existente
    public Receita editar(Long id, Receita receitaAtualizada) {
        // Verifica se a receita existe
        Receita receita = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Receita não encontrada com ID: " + id));

        // Atualiza os dados da receita
        receita.setDescricao(receitaAtualizada.getDescricao());
        receita.setValor(receitaAtualizada.getValor());

        // Salva as mudanças
        return repository.save(receita);
    }

    // Excluir uma receita pelo ID
    public void excluir(Long id) {
        repository.deleteById(id);  // Exclui a receita com o ID fornecido
    }
}

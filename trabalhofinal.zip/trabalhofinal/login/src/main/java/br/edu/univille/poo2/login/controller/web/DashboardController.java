package br.edu.univille.poo2.login.controller.web;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Controlador para a página Dashboard.
 */
@Controller
public class DashboardController {

    /**
     * Método para renderizar a página de dashboard.
     *
     * @return ModelAndView com a página de dashboard.
     */
    @GetMapping("/dashboard")
    public ModelAndView dashboard() {
        ModelAndView modelAndView = new ModelAndView();

        // Verificar se o usuário está autenticado
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (principal instanceof User) {
            // Renderiza a página do dashboard
            modelAndView.setViewName("dashboard");
        } else {
            // Redireciona para a página de login caso não autenticado
            modelAndView.setViewName("redirect:/login");
        }

        return modelAndView;
    }
}

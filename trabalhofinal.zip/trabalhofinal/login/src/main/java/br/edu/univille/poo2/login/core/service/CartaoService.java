package br.edu.univille.poo2.login.core.service;

import br.edu.univille.poo2.login.core.entity.Cartao;
import br.edu.univille.poo2.login.core.repository.CartaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartaoService {

    @Autowired
    private CartaoRepository repository;

    // Método para listar todos os cartões
    public List<Cartao> listarTodos() {
        return repository.findAll();
    }

    // Método para salvar um cartão
    public Cartao salvar(Cartao cartao) {
        return repository.save(cartao);
    }

    // Método para excluir um cartão
    public void excluir(Long id) {
        repository.deleteById(id);
    }

    // Método para contar os cartões ativos diretamente no banco de dados
    public long contarCartoesAtivos() {
        return repository.countByAtivo(true);  // Método no seu repositório para contar cartões ativos
    }

    // Método para calcular o valor total das faturas (Assumindo que 'getFatura' existe na classe Cartao)
    public double calcularValorTotalFaturas() {
        return repository.findAll().stream()
                .filter(Cartao::isAtivo)  // Garantir que apenas cartões ativos sejam contados
                .mapToDouble(Cartao::getFatura)  // Aqui, presumo que 'getFatura' existe na classe Cartao
                .sum();
    }

}

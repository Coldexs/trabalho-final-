package br.edu.univille.poo2.login.controller.web;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/u/home")
public class HomeController {

    @GetMapping
    public ModelAndView inicio() {
        // Obter o principal (usuário autenticado)
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        // Verificar se é do tipo UserDetails e extrair o nome
        String username = "Guest"; // Valor padrão caso o principal seja do tipo String
        if (principal instanceof User) {
            username = ((User) principal).getUsername();
        } else if (principal instanceof String) {
            username = (String) principal;
        }

        // Adicionar o nome do usuário ao modelo
        ModelAndView modelAndView = new ModelAndView("home/index");
        modelAndView.addObject("username", username);

        return modelAndView;
    }
}

package br.edu.univille.poo2.login.core.entity;


import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "users") // Define o nome da tabela no banco de dados
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Geração automática do ID
    private Long id;

    @Column(nullable = false, unique = true, length = 50) // Define restrições e tamanho
    private String username; // Nome de usuário (deve ser único)

    @Column(nullable = false, length = 100) // Tamanho definido para a senha codificada
    private String password; // Senha (codificada com BCrypt)

    @Column(nullable = false)
    private boolean active; // Define se o usuário está ativo

    // Relacionamento ManyToOne: Um usuário tem um papel
    @ManyToOne(fetch = FetchType.LAZY) // Carregamento atrasado para melhorar o desempenho
    @JoinColumn(name = "role_id", nullable = false) // Nome da coluna na tabela de banco de dados
    private UserRole role; // Papel associado ao usuário (admin, user, etc.)
}

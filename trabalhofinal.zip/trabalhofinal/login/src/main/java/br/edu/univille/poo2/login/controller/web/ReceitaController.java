package br.edu.univille.poo2.login.controller.web;

import br.edu.univille.poo2.login.core.entity.Receita;
import br.edu.univille.poo2.login.core.service.ReceitaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@Controller
@RequestMapping("/receitas")
public class ReceitaController {

    @Autowired
    private ReceitaService service;

    // Rota para exibir todas as receitas
    @GetMapping
    public String listarReceitas(Model model) {
        model.addAttribute("receitas", service.listarTodas());  // Adiciona a lista de receitas ao modelo
        return "receitas";  // Retorna a view "receitas.html"
    }

    // Rota para adicionar uma nova receita
    @PostMapping
    public String adicionarReceita(@Valid Receita receita, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Erro ao adicionar receita!");
            return "receitas";  // Retorna à página de receitas se houver erro na validação
        }
        service.salvar(receita);  // Chama o serviço para salvar a receita
        return "redirect:/receitas";  // Redireciona para a página de listagem de receitas
    }

    // Rota para editar uma receita existente
    @PutMapping("/editar/{id}")
    public String editarReceita(@PathVariable Long id, @Valid Receita receita, BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("erro", "Erro ao editar receita!");
            return "receitas";  // Retorna à página de receitas se houver erro na validação
        }
        service.editar(id, receita);  // Chama o serviço para editar a receita
        return "redirect:/receitas";  // Redireciona para a página de listagem de receitas
    }

    // Rota para excluir uma receita
    @DeleteMapping("/excluir/{id}")
    public String excluirReceita(@PathVariable Long id) {
        service.excluir(id);  // Chama o serviço para excluir a receita
        return "redirect:/receitas";  // Redireciona para a página de listagem de receitas
    }
}

package br.edu.univille.poo2.login.core.repository;

import br.edu.univille.poo2.login.core.entity.Receita;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReceitaRepository extends JpaRepository<Receita, Long> {
}

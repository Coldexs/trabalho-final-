package br.edu.univille.poo2.login.core.service;

import br.edu.univille.poo2.login.core.entity.Despesa;
import br.edu.univille.poo2.login.core.repository.DespesaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class DespesaService {

    @Autowired
    private DespesaRepository repository;

    // Listar todas as despesas
    public List<Despesa> listarTodas() {
        return repository.findAll();
    }

    // Adicionar uma nova despesa
    public Despesa salvar(Despesa despesa) {
        validarDespesa(despesa); // Chamada de validação
        return repository.save(despesa);
    }

    // Editar uma despesa existente
    public Despesa editar(Long id, Despesa despesaAtualizada) {
        Despesa despesa = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Despesa não encontrada com ID: " + id));

        // Atualiza os campos da despesa
        despesa.setDescricao(despesaAtualizada.getDescricao());
        despesa.setValor(despesaAtualizada.getValor());

        // Validação antes de salvar
        validarDespesa(despesa);

        return repository.save(despesa);
    }

    // Excluir uma despesa pelo ID
    public void excluir(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Despesa não encontrada com ID: " + id);
        }
        repository.deleteById(id);
    }

    // Verificar se a despesa existe
    public boolean existePorId(Long id) {
        return repository.existsById(id);
    }

    // Método de validação (pode ser expandido conforme necessário)
    private void validarDespesa(Despesa despesa) {
        if (despesa.getDescricao() == null || despesa.getDescricao().isEmpty()) {
            throw new IllegalArgumentException("Descrição da despesa é obrigatória.");
        }
        if (despesa.getValor() <= 0) {
            throw new IllegalArgumentException("Valor da despesa deve ser maior que zero.");
        }
    }

    // Exemplo de método para buscar despesas por valor mínimo
    public List<Despesa> buscarPorValorMinimo(double valorMinimo) {
        return repository.findByValorGreaterThanEqual(valorMinimo);
    }

    // Exemplo de método para buscar despesas por descrição (parcial)
    public List<Despesa> buscarPorDescricao(String descricao) {
        return repository.findByDescricaoContaining(descricao);
    }
}

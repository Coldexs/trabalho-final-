package br.edu.univille.poo2.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Classe principal para inicialização da aplicação.
 * Marca o ponto de entrada do sistema com a anotação @SpringBootApplication,
 * que configura o Spring Boot automaticamente.
 */
@SpringBootApplication
public class MainApplication {

    /**
     * Método principal para iniciar a aplicação.
     *
     * @param args Argumentos de linha de comando (opcionais).
     */
    public static void main(String[] args) {
        SpringApplication.run(MainApplication.class, args);
        System.out.println("Aplicação inicializada com sucesso!");
    }
}

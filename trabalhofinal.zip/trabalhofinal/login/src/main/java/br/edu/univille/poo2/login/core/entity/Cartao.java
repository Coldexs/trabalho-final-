package br.edu.univille.poo2.login.core.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Cartao {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String bandeira;
    private String numeroCartao;
    private String cvv;
    private String validade;
    private String titularCartao;
    private String banco;
    private String cpfTitular;
    private boolean ativo;
    // Método para verificar se o cartão está ativo
    public boolean isAtivo() {
        return ativo;
    }

    // Adicionando campo de fatura
    private double fatura;  //

    // Outros métodos podem ser adicionados conforme necessário
}

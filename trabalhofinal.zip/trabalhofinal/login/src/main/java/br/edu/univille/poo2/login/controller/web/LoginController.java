package br.edu.univille.poo2.login.controller.web;

import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/login")
public class LoginController {

    @GetMapping
    public ModelAndView loginPage() {
        // Verifica se o usuário já está autenticado
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        ModelAndView modelAndView = new ModelAndView();

        if (principal instanceof User) {
            // Se já estiver autenticado, redireciona para a página dashboard
            modelAndView.setViewName("redirect:/u/dashboard");
        } else {
            // Se não estiver autenticado, exibe a página de login (teladelogin)
            modelAndView.setViewName("teladelogin");
        }

        return modelAndView;
    }
}

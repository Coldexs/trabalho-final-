package br.edu.univille.poo2.login.core.repository;

import br.edu.univille.poo2.login.core.entity.Cartao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CartaoRepository extends JpaRepository<Cartao, Long> {
    // Método para contar cartões ativos
    long countByAtivo(boolean ativo);
}
